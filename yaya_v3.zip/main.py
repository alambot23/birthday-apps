from kivy.app import App
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.clock import Clock
from kivy.core.audio import SoundLoader
from kivy.graphics.texture import Texture
from kivy.uix.popup import Popup
from kivy.animation import Animation
from android.permissions import request_permissions, Permission
import cv2
import time
import os

class CameraEffect(FloatLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.capture = cv2.VideoCapture(0)
        self.image = Image()
        self.add_widget(self.image)
        
        self.overlay = Image(source='birthday_overlay.png', allow_stretch=True, size_hint=(1, 1), opacity=0.7)
        self.add_widget(self.overlay)

        self.sound = SoundLoader.load('music.mp3')
        if self.sound:
            self.sound.play()

        self.label = Label(text='🎉 Selamat Ulang Tahun Imoept 🎉',
                           font_size='30sp',
                           pos_hint={'center_x': 0.5, 'y': 0.9},
                           color=(1, 0.5, 0.9, 1))
        self.add_widget(self.label)
        self.animate_text(self.label)

        Clock.schedule_interval(self.update, 1.0 / 30.0)
        Clock.schedule_once(self.capture_photo, 5)
        Clock.schedule_once(self.capture_video, 10)
    
    def animate_text(self, label):
        anim = Animation(pos_hint={'center_x': 0.5, 'y': 0.6}, duration=1) +                Animation(pos_hint={'center_x': 0.5, 'y': 0.9}, duration=1)
        anim.repeat = True
        anim.start(label)
    
    def update(self, dt):
        ret, frame = self.capture.read()
        if ret:
            buf = cv2.flip(frame, 0).tobytes()
            img_texture = Texture.create(size=(frame.shape[1], frame.shape[0]), colorfmt='bgr')
            img_texture.blit_buffer(buf, colorfmt='bgr', bufferfmt='ubyte')
            self.image.texture = img_texture
            self.last_frame = frame

    def capture_photo(self, dt):
        if hasattr(self, 'last_frame'):
            filename = f'/sdcard/Download/foto_ulangtahun_{int(time.time())}.png'
            cv2.imwrite(filename, self.last_frame)
            print(f"📸 Foto disimpan di: {filename}")

    def capture_video(self, dt):
        if hasattr(self, 'last_frame'):
            filename = f'/sdcard/Download/video_ulangtahun_{int(time.time())}.avi'
            fourcc = cv2.VideoWriter_fourcc(*'XVID')
            out = cv2.VideoWriter(filename, fourcc, 20.0, (640, 480))
            for _ in range(100):
                ret, frame = self.capture.read()
                if ret:
                    out.write(frame)
            out.release()
            print(f"🎥 Video disimpan di: {filename}")

class BirthdayApp(App):
    def build(self):
        self.show_permission_message()
        return CameraEffect()

    def show_permission_message(self):
        popup = Popup(title='🎥 Izinkan Kamera',
                      content=Label(text='Izinkan buka kamera-nya ya Imoput 🥺👉👈'),
                      size_hint=(0.8, 0.3))
        popup.open()
        Clock.schedule_once(lambda dt: request_permissions([Permission.CAMERA, Permission.WRITE_EXTERNAL_STORAGE]), 1)

if __name__ == '__main__':
    BirthdayApp().run()